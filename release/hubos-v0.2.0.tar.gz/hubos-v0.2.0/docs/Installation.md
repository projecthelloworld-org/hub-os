# Install HubOS

HubOS provides an interactive terminal installer and a modular Docker Compose environment. Choose a published release for a reproducible installation; use a source checkout when contributing or evaluating unreleased capabilities.

**Security notice:** v0.1.0 includes Metabase 0.60.7, affected by a critical upstream advisory. Do not expose it publicly or use it for sensitive data. Read [Metabase upgrade guidance](Metabase_Compatibility.md) and the [upstream advisory](https://github.com/metabase/metabase/security/advisories/GHSA-vwf4-m7j8-wcjf).

## Requirements

- A supported operating system with a running Docker engine and Compose plugin.
- Enough memory/storage for the selected services, persistent data and backups.
- Network access to download release assets and container images.
- Git when fetching optional upstream ODK/Headwind deployments.
- A person responsible for credentials, source access, updates and restoration.

The installer does not install Docker silently. Supported Ubuntu/Debian installation requires approval; on macOS, install and start your chosen Docker application first. Compose 2.24.4 or later is required by the source stack's explicit port-list overrides.

## Stable one-command installation

```sh
curl -fsSL https://hubos.myhellohub.org/install.sh | bash
```

Review a downloaded script before execution. The installer reads answers from the terminal even when piped, verifies the embedded archive checksum and extracts the selected package. It asks for bind/port settings and Metabase administrator details, generates independent service secrets and creates an owner-readable `.env`.

The public endpoint follows GitHub's latest stable release, excluding drafts/prereleases. Check the linked release notes before deployment. The earlier v0.1.0 package is a demonstration scaffold; v0.2.0 adds community-site monitoring. [The roadmap](Roadmap.md) defines those boundaries.

For a fixed release, use the required published tag:

```sh
curl -fsSL https://hubos.myhellohub.org/releases/v0.2.0/install.sh | bash
```

The installer is a separate release asset, excluded from the checksum-sealed archive. Download it alongside an unpacked release, or use the versioned URL above. From a release checkout containing the script, run `./install.sh`. Use `./install.sh --help` for its exact options. `--profile ecosystem` includes optional ODK Central and Headwind MDM; these require additional resources and upstream configuration.

## Source checkout and demonstration

Follow [contributor setup](Local_Development.md) rather than assuming that an installer from an unreleased checkout has the same contract as a published package. Configure operator authentication and private credentials before starting the source Compose stack.

Default local addresses are HubOS `http://localhost:8080`, Metabase `http://localhost:3001`, Kuma `http://localhost:3002` and Mailpit `http://localhost:8025`. Tool availability depends on the installed release and enabled layers.

The v0.2.0 installer offers `--mode demo` and `--mode live`. Demonstration mode includes fictional community sites; live mode excludes the seed layer and unconfigured sources. These options are not available in the v0.1.0 installer.

```sh
./install.sh --mode live
```

Interactive setup collects operator, Metabase and Kuma account details. It generates independent service/reporting and source-webhook credentials, hashes the operator password with the pinned Caddy image and keeps administrator passwords in `.hubos-credentials`, readable only by its owner. Passwords are not printed to terminal logs. Protect that file alongside `.env`; do not commit, share or source it as a shell script.

The source installer includes the monitoring layer and waits for successful migration, dashboard and Kuma provisioning as well as application health. A failed provisioning task is an installation failure, even if a dashboard application is already reachable. `--no-start` prepares and validates configuration but does not prove that provisioning or connections have succeeded.

New Metabase instances do not load its unrelated sample commerce database or dashboards. HubOS supplies its own community-focused dashboards and explicitly selected demonstration data instead. This uses Metabase's supported [sample-content setting](https://www.metabase.com/docs/latest/configuring-metabase/environment-variables#mb_load_sample_content), not a cleanup that deletes existing operator resources.

Synthetic demonstration records must stay separate from live data. Do not reseed a live deployment or interpret generated faults as field observations.

## Unattended installation

Provide release-supported settings through a protected environment or secret manager. For v0.2.0:

```sh
METABASE_ADMIN_EMAIL=operator@example.org \
METABASE_ADMIN_PASSWORD='replace-with-a-private-secret' \
HUBOS_BIND_ADDRESS=127.0.0.1 \
./install.sh --non-interactive --yes
```

Do not store actual secrets in shell history, shared logs or example files. Omitted supported service secrets are generated. `--no-start` prepares configuration without starting containers; `--install-dir PATH` selects the installation directory.

A reviewed mirror archive requires both `HUBOS_RELEASE_URL` and its verified `HUBOS_RELEASE_SHA256`. Changing the URL does not waive checksum validation.

## Existing installations and upgrades

The installer preserves an existing `.env` rather than silently rotating credentials attached to persistent databases. Changing a database password in `.env` alone does not rotate the password in that database.

The source installer adds missing monitoring settings without replacing existing database passwords, application encryption keys or tool accounts. Repeated setup preserves those settings. An installation cannot silently change from demonstration to live mode: use a separate directory and fresh volumes so fictional history is not mistaken for operational evidence.

The v0.2.0 installer stages checksum-verified release upgrades for unpacked deployments. When the selected release differs from the saved package identity, it asks for upgrade confirmation. Take a consistent backup first. Non-interactive upgrades require `--yes`, which also accepts that confirmation. A script downloaded into an existing deployment can use `--upgrade` to request the sealed package explicitly; Git checkouts must instead be updated through Git.

An upgrade retains `.env`, `.hubos-credentials`, private files and operator files absent from the new package. Release-owned files, including Compose definitions and the default Caddy configuration, are replaced; review local edits before proceeding. The previous source tree is retained in an owner-accessible sibling directory named `<installation>.pre-upgrade-<id>`. That directory contains private configuration but is **not a database backup**. Review and remove it deliberately after verifying the upgraded installation and securing an off-host backup.

Services are paused only after the new package has been verified and staged. The installation directory and existing bind-mounted directories remain in place while managed files are replaced; the new package receipt is saved only after copying succeeds. Public source permissions are preserved for non-root containers, while generated credential files remain owner-readable only.

Starting an upgrade recreates containers against the retained data namespace and waits for provisioning. `--no-start` upgrades require services to be stopped already. If copying, startup or migrations fail, services may remain paused: inspect the error, preserve the backup and rerun the installer after correcting the problem. Do not undo a database migration by replacing source files alone.

A sibling `<installation>.install-lock` prevents concurrent installers. Normal exit removes the lock; after a force-killed process, confirm that no installer is running before removing a stale lock. Never remove another active installer's lock.

New source installations save a distinct Docker project name in `COMPOSE_PROJECT_NAME`. A requested name with existing containers or retained volumes is rejected for a fresh installation. Upgrades preserve the saved name; legacy v0.1.0 installations retain their original `hubos` namespace unless they were explicitly configured otherwise. Keep this name with the installation configuration: a different name selects different persistent storage, not an upgrade of the original data.

Before an upgrade, preserve:

- HubOS PostgreSQL and Metabase application databases.
- Installation configuration, `.hubos-credentials`, source secret files and encryption keys.
- Kuma data and HubOS-managed secret storage where present.
- Caddy certificate/configuration storage.
- Optional ODK/Headwind data according to upstream backup procedures.

Restore rehearsal must use fresh isolated volumes, not the running installation. Preserve tool encryption secrets and use matching images when restoring. Follow [Metabase upgrade/rollback guidance](Metabase_Compatibility.md); do not attach an experimental version to an original database.

The source tree's [backup and restore guide](Backup_and_Restore.md) describes core snapshots, Kuma's maintenance pause and recovery into a distinct, stopped deployment. Optional ODK and Headwind data require separate upstream backups.

## Remote exposure

Keep direct tool/database ports private. Remote access needs verified TLS, deliberate DNS/listener configuration, strong credentials, reviewed firewall exposure and a tested recovery plan. [The access guide](Security_and_Access.md) explains the trusted boundary and its limitations.

For a fresh v0.2.0 source deployment, configure a deployment hostname distinct from the public installer domain. Point its A/AAAA records to your server, allow inbound TCP 80/443 to Caddy and allow certificate-authority access. Then configure the operator origin and listeners during interactive setup, or provide non-secret settings:

```sh
HUBOS_SITE_ADDRESS=https://monitoring.example.org \
HUBOS_BIND_ADDRESS=0.0.0.0 \
HUBOS_HTTP_PORT=80 HUBOS_HTTPS_PORT=443 \
./install.sh --mode live
```

The installer selects `compose/tls.compose.yaml`, rejects malformed origins or mismatched listener ports, and waits for a certificate-verified HTTPS readiness response. `--no-start` does not prove that DNS or certificates work. Existing installations preserve their settings; review and change only the relevant network settings in `.env` before rerunning setup, without rotating persistent credentials.

The TLS layer publishes Caddy's HTTP redirect and HTTPS listener. Metabase, Kuma, Mailpit and optional Headwind/ODK host ports remain on loopback; setting `HUBOS_BIND_ADDRESS` does not make those applications public. Use a secure tunnel for administration, or a separately reviewed upstream HTTPS deployment. Never disable certificate verification to bypass a provisioning failure.

[Caddy automatic HTTPS](https://caddyserver.com/docs/automatic-https) describes certificate issuance, renewal, DNS and externally reachable challenge ports. Custom HTTPS ports must match the configured origin and require appropriate 80/443 forwarding for public certificate challenges. The local-CA test configuration is test-only and is not installed for public deployments.

Docker's published ports can interact with host firewall rules differently from ordinary host processes. Review the effective exposure rather than assuming a host firewall protects every published port.

## Installer publication

Release maintainers use the `Release` and `Publish installer` workflows. Publication validates installer metadata, archive checksums and Bash syntax before deploying the Pages payload. Archives, SBOMs and checksum manifests stay in GitHub release assets.

The public installer domain is distinct from operator deployment domains. Its Pages custom-domain/DNS settings belong to project maintenance, not a requirement for self-hosting HubOS. See the [release checklist](../.github/RELEASE_CHECKLIST.md).
